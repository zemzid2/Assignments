#include<iostream>

class BankAccount{
    private:
    std::string accountNumber;
    double balance;

    public:
    BankAccount (const std :: string &accNum);
    void deposit(double amount);
    void withdraw(double amount);
    void checkBalance() const;
};

BankAccount::BankAccount(const std::string &accNum){
    accountNumber = accNum;
    balance = 0;
}
void BankAccount::deposit(double amount){
    balance += amount;
}
void BankAccount::withdraw(double amount){
    if(amount <= balance){
        balance -= amount;
    }else{
        std::cout << "Insufficient funds" << std::endl;
    }
}
void BankAccount::checkBalance()const{
    std::cout<<"Account Balance: "<< balance<< std::endl;
}
int main(){
    std::string accNum;
    std::cout<<"Enter Account number: ";
    std::cin>>accNum;

    BankAccount userAccount(accNum);

    int choice;
    double amount;

    do{
        std::cout<<"Menu\n";
        std::cout<<"1.Deposit\n";
        std::cout<<"2.Withdraw\n";
        std::cout<<"3.Check Balance\n";
        std::cout<<"4.Exit\n";
        std::cout<<"Enter your choice: ";
        std::cin>>choice;

        switch(choice){
            case 1: {
                std::cout<<"Enter amount to deposit: ";
                std::cin>>amount;
                userAccount.deposit(amount);
                break;
            }
            case 2:{
                std::cout<<"Enter amount to withdraw: ";
                std::cin>>amount;
                userAccount.withdraw(amount);
                break;
            }
            case 3:{
                userAccount.checkBalance();
                break;
            }
            case 4:{
                break;
            }
            default:{
                std::cout<<"Invalid choice. Please try again."<<std::endl;
                break;
            }
        }
    }while(choice !=4);

return 0;
}