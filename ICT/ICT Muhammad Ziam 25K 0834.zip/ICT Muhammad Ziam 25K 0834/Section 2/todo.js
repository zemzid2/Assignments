const prompt = require("prompt-sync")({ sigint: true });

let tasks = [];

function addTask() {
    const task = prompt("Enter a task to add: ");

    if (task.trim() === "") {
        console.log("Error: Task cannot be empty.");
        return;
    }

    tasks.push(task);
    console.log(`Task added: "${task}"`);
}

function removeTask() {
    displayTasks();
    if (tasks.length === 0) return;

    const index = parseInt(prompt("Enter task number to remove: "));

    if (isNaN(index) || index < 1 || index > tasks.length) {
        console.log("Error: Invalid task number.");
        return;
    }

    const removed = tasks.splice(index - 1, 1);
    console.log(`Removed: "${removed}"`);
}

function displayTasks() {
    if (tasks.length === 0) {
        console.log("No tasks available.");
        return;
    }

    console.log("\nYour Tasks:");
    tasks.forEach((task, i) => {
        console.log(`${i + 1}. ${task}`);
    });
    console.log("");
}

function clearTasks() {
    tasks = [];
    console.log("All tasks cleared.");
}

function main() {
    console.log("===== TO-DO LIST MANAGER =====");

    while (true) {
        const command = prompt("Enter command (add, remove, view, clear, exit): ").toLowerCase();

        switch (command) {
            case "add":
                addTask();
                break;

            case "remove":
                removeTask();
                break;

            case "view":
                displayTasks();
                break;

            case "clear":
                clearTasks();
                break;

            case "exit":
                console.log("Exiting program...");
                return;

            default:
                console.log("Error: Invalid command.");
        }
    }
}

main();
